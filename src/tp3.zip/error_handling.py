import os
from error_messages import *
from constants import *

def _parameters_error_handler(param_count: int, parameters: tuple) -> bool:
    if len(parameters) != param_count:
        print(ERROR_PARAM_COUNT)
        return False
    return True

def clustering_parameter_error_handler(param_count: int, parameters: tuple) -> bool:
    if not len(parameters) <= param_count:
        print(ERROR_PARAM_COUNT)
        return False
    return True

def parameters_error_handler(command: str, param_count: int, parameters: list) -> bool:
    '''
    Verifica que la cantidad de parametros sea valida para cada comando.
    Pre: se verifico el ingreso por consola.
    '''
    if command != CLUSTERING:
        return _parameters_error_handler(param_count, parameters)
    return clustering_parameter_error_handler(param_count, parameters)

def command_handle_error(command: str) -> bool:
    '''
    Verifica que el comando ingresado sea valido.
    Pre: se verifico el ingreso por consola.
    '''
    if command not in COMMANDS:
        print(ERROR_CMD)
        return False
    return True
    
def input_handle_error(splitted_line: list) -> bool:
    '''
    Verifica que la entrada por consola sea valida.
    Pre: se ingreso por consola.
    '''
    if len(splitted_line) < 1:
        print(ERROR_INPUT)
        return False
    elif len(splitted_line) == 1:
        if CLUSTERING in splitted_line:
            return True
        else:
            print(ERROR_PARAM_COUNT)
            return False
    return True

def path_handle_error(path: str) -> None:
    if not os.path.exists(path):
        raise FileNotFoundError("Buscate un archivo de verdad.")